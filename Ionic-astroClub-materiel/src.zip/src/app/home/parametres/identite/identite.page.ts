import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-identite',
  templateUrl: './identite.page.html',
  styleUrls: ['./identite.page.scss'],
})
export class IdentitePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
