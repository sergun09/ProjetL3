import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gestion-parc',
  templateUrl: './gestion-parc.page.html',
  styleUrls: ['./gestion-parc.page.scss'],
})
export class GestionParcPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
