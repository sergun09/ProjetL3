import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nouvel-adherent',
  templateUrl: './nouvel-adherent.page.html',
  styleUrls: ['./nouvel-adherent.page.scss'],
})
export class NouvelAdherentPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
