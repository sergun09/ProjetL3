import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adherents',
  templateUrl: './adherents.page.html',
  styleUrls: ['./adherents.page.scss'],
})
export class AdherentsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
