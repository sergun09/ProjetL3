import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emprunts-tiers',
  templateUrl: './emprunts-tiers.page.html',
  styleUrls: ['./emprunts-tiers.page.scss'],
})
export class EmpruntsTiersPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
