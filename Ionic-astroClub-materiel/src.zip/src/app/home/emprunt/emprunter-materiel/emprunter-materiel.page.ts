import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emprunter-materiel',
  templateUrl: './emprunter-materiel.page.html',
  styleUrls: ['./emprunter-materiel.page.scss'],
})
export class EmprunterMaterielPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
