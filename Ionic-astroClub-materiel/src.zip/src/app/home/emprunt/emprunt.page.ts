import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emprunt',
  templateUrl: './emprunt.page.html',
  styleUrls: ['./emprunt.page.scss'],
})
export class EmpruntPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
