import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mes-emprunts',
  templateUrl: './mes-emprunts.page.html',
  styleUrls: ['./mes-emprunts.page.scss'],
})
export class MesEmpruntsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
