import { Materiel } from './materiel.model';

describe('Materiel', () => {
  it('should create an instance', () => {
    expect(new Materiel()).toBeTruthy();
  });
});
