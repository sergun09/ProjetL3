import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inventaire',
  templateUrl: './inventaire.page.html',
  styleUrls: ['./inventaire.page.scss'],
})
export class InventairePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
