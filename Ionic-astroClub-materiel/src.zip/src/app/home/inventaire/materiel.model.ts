export class Materiel {
  constructor(public id: number,public type: string,public intitule: string, public desc: string, public kit: string,public conditionnement: string,public etat: string, public emprunt: string, public montantCaution: number,public commantaire:string,public enMaintenance:string ){}
}
